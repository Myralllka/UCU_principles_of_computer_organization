#ifndef FUNCTION_MAIN_H
#define FUNCTION_MAIN_H

int first_three_equal_to_second_three(unsigned int number);

int number_of_digits(unsigned int n);

int sum_of_three(unsigned int val);

#endif //FUNCTION_MAIN_H

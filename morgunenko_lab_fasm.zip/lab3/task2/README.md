HOW I DID IT?

in Cutter find needed bit using asm code and hexdump of a file

just debug the code and found that I have to change 'jne' to 'je'

in vim changed the bit using xxd program
(screenshots in the folder)



TASK 13

Функція приймає перший член геометричної прогресії, її знаменник та кількість улументів, як 32-,snys floating point, повертає її суму.

there is a makefile for building the program
just run `make` from the current directory and executable files will be in the ./bin directory. 

***func_sum.s*** is the function to TASK 13 writen on fasm. There is full description of every step in the function, just open it in text editor that you prefere. 
***main.s*** is the example of calling function from assembly. ***./bin/call_from_asm*** is the executable file. parameters are hardcoded in the end of ***main.s***.
***test.c*** is the file with 2 same functions: one on the `C` and one on the FASM. ***call_from_c*** is the executable file. values are also hardcoded in the ***test.c*** module, and the result of calling ***call_from_c*** is comparing of results function on `C` and on `FASM`

FOLDER TASK2

it is the folder with second task of this lab work. README is also there so you can read it.

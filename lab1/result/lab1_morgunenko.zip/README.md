You need to move setpath.sh after "make" to ./bin/ directory end start it from there
to compile files in debug mode just add " -d " to CFLAGS var
to compile files in optimize mode just add " -O3 " to CFLAGS var
